import React, { useState, useEffect } from "react";
import { Table, Input, Select, Button, Modal, Form, message, InputNumber } from "antd";
import { ExclamationCircleOutlined } from "@ant-design/icons";

const { Option } = Select;
const { confirm } = Modal;

interface Room {
  id: string;
  name: string;
  seats: number;
  type: string;
  manager: string;
}

const roomTypes = ["Lý thuyết", "Thực hành", "Hội trường"];
const managers = ["Nguyễn Văn A", "Trần Thị B", "Phạm Văn C"];

const RoomManagement: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [filteredRooms, setFilteredRooms] = useState<Room[]>([]);
  const [searchText, setSearchText] = useState("");
  const [filterType, setFilterType] = useState<string | undefined>(undefined);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [form] = Form.useForm();

  useEffect(() => {
    const storedRooms = localStorage.getItem("rooms");
    if (storedRooms) {
      const parsedRooms = JSON.parse(storedRooms);
      setRooms(parsedRooms);
      setFilteredRooms(parsedRooms);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("rooms", JSON.stringify(rooms));
    setFilteredRooms(
      rooms.filter((room) =>
        room.name.toLowerCase().includes(searchText.toLowerCase())
      ).filter((room) => (filterType ? room.type === filterType : true))
    );
  }, [rooms, searchText, filterType]);

  const handleDelete = (id: string, seats: number) => {
    if (seats >= 30) {
      message.warning("Chỉ có thể xóa phòng dưới 30 chỗ ngồi.");
      return;
    }
    confirm({
      title: "Bạn có chắc chắn muốn xóa phòng này?",
      icon: <ExclamationCircleOutlined />,
      onOk() {
        const updatedRooms = rooms.filter((room) => room.id !== id);
        setRooms(updatedRooms);
        setFilteredRooms(updatedRooms);
        message.success("Xóa phòng thành công");
      },
    });
  };

  const handleEdit = (room: Room) => {
    setEditingRoom(room);
    form.setFieldsValue(room);
    setIsModalOpen(true);
  };

  const handleAddOrUpdate = (values: any) => {
    if (editingRoom) {
      const updatedRooms = rooms.map((room) =>
        room.id === editingRoom.id ? { ...room, ...values } : room
      );
      setRooms(updatedRooms);
      setFilteredRooms(updatedRooms);
      message.success("Cập nhật phòng thành công");
    } else {
      const newRoom = { id: Date.now().toString(), ...values };
      setRooms([...rooms, newRoom]);
      setFilteredRooms([...rooms, newRoom]);
      message.success("Thêm phòng mới thành công");
    }
    setIsModalOpen(false);
    form.resetFields();
    setEditingRoom(null);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Quản lý phòng học</h2>
      <Input.Search
        placeholder="Tìm kiếm theo tên phòng"
        onChange={(e) => setSearchText(e.target.value)}
        style={{ width: 300, marginRight: 10 }}
      />
      <Select
        placeholder="Lọc theo loại phòng"
        allowClear
        onChange={setFilterType}
        style={{ width: 200, marginRight: 10 }}
        options={roomTypes.map((type) => ({ label: type, value: type }))}
      />
      <Button type="primary" onClick={() => setIsModalOpen(true)}>Thêm phòng</Button>
      
      <Table dataSource={filteredRooms} rowKey="id" style={{ marginTop: 20 }}>
        <Table.Column title="Mã phòng" dataIndex="id" key="id" />
        <Table.Column title="Tên phòng" dataIndex="name" key="name" />
        <Table.Column title="Số chỗ ngồi" dataIndex="seats" key="seats" />
        <Table.Column title="Loại phòng" dataIndex="type" key="type" />
        <Table.Column title="Người phụ trách" dataIndex="manager" key="manager" />
        <Table.Column
          title="Hành động"
          key="actions"
          render={(_text, record: Room) => (
            <>
              <Button onClick={() => handleEdit(record)} style={{ marginRight: 8 }}>Sửa</Button>
              <Button danger onClick={() => handleDelete(record.id, record.seats)}>Xóa</Button>
            </>
          )}
        />
      </Table>
      
      <Modal
        title={editingRoom ? "Chỉnh sửa phòng" : "Thêm phòng mới"}
        open={isModalOpen}
        onCancel={() => {
          setIsModalOpen(false);
          form.resetFields();
        }}
        onOk={() => form.submit()}
      >
        <Form form={form} onFinish={handleAddOrUpdate} layout="vertical">
          <Form.Item name="name" label="Tên phòng" rules={[{ required: true, max: 50 }]}>
            <Input />
          </Form.Item>
          <Form.Item name="seats" label="Số chỗ ngồi" rules={[{ required: true, type: "number" }]}> 
            <InputNumber min={1} />
          </Form.Item>
          <Form.Item name="type" label="Loại phòng" rules={[{ required: true }]}>
            <Select>
              {roomTypes.map((type) => (<Option key={type} value={type}>{type}</Option>))}
            </Select>
          </Form.Item>
          <Form.Item name="manager" label="Người phụ trách" rules={[{ required: true }]}>
            <Select>
              {managers.map((m) => (<Option key={m} value={m}>{m}</Option>))}
            </Select>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default RoomManagement;
